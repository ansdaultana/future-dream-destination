<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UaeVisaController extends Controller
{
    //
}

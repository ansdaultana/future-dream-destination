
<script setup>
import AppLayout from '@/Layouts/AppLayout.vue'
import { Head } from '@inertiajs/vue3';
</script>

<template>
    <Head title="Dashboard" />

  <AppLayout>

<h1 class="text-white font-bold bg-blue-500 p-5 ">
    Dashboard
</h1>  
</AppLayout>

    
</template>
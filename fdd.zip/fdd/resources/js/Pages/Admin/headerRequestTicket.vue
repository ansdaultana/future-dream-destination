<script setup></script>

<template>
    <div class="flex bg-blue-400 p-2 border-2  rounded-lg justify-between text-white">
        <div class=" ml-5 w-32 hidden md:block">
            Name
        </div>
        <div class="w-28 ">
            to
        </div>
        <div class="w-32 ">
            from
        </div>

        <div class="w-36 ">
            Service
        </div>
        <div class="w-36 hidden lg:block">
            Date of Travel
        </div>
        <div class="w-40">
            Actions
        </div>
    </div>
</template>
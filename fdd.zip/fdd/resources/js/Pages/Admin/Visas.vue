
<script setup>
import AppLayout from '@/Layouts/AppLayout.vue'
import { Head } from '@inertiajs/vue3';
</script>

<template>
    <Head title="Visas" />

  <AppLayout>

<h1 class="text-black">
    Visas
</h1>  
</AppLayout>

    
</template>